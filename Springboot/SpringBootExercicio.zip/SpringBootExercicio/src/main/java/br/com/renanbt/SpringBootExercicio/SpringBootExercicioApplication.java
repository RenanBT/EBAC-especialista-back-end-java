package br.com.renanbt.SpringBootExercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExercicioApplication.class, args);
	}

}
